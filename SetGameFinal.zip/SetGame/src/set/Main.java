package set;
import set.ui.SetUI;

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        SetUI game = new SetUI();
    }
}
