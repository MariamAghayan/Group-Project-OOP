package set.core;

public class Player {
    private int points;
    public Player(){
        points = 0;
    }
    public void addPoints(int a){
        this.points+=a;
    }
    public int getPoints(){
        return points;
    }

}
